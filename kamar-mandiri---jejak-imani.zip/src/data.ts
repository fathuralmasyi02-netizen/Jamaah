import { Hotel, SnackItem } from './types';

export const HOTELS_SAUDI: Hotel[] = [
  // Mekkah Hotels
  { id: 'm1', name: 'Pullman Zamzam Makkah', city: 'Mekkah' },
  { id: 'm2', name: 'Swissôtel Makkah', city: 'Mekkah' },
  { id: 'm3', name: 'Fairmont Makkah Clock Royal Tower', city: 'Mekkah' },
  { id: 'm4', name: 'Hilton Suites Makkah', city: 'Mekkah' },
  { id: 'm5', name: 'Makkah Towers', city: 'Mekkah' },
  
  // Madinah Hotels
  { id: 'md1', name: 'Dar Al Iman InterContinental Madinah', city: 'Madinah' },
  { id: 'md2', name: 'Anwar Al Madinah Mövenpick', city: 'Madinah' },
  { id: 'md3', name: 'Pullman Zamzam Madinah', city: 'Madinah' },
  { id: 'md4', name: 'Maden Hotel Al Madinah', city: 'Madinah' },
  { id: 'md5', name: 'Al Aqeeq InterContinental Madinah', city: 'Madinah' },
];

export const SNACKS_MENU: SnackItem[] = [
  {
    id: 's1',
    name: 'Paket Kurma Ajwa & Air Zamzam Utama',
    description: 'Kurma nabi premium bertekstur empuk yang disajikan manis bersama segelas Air Zamzam dingin menyegarkan.'
  },
  {
    id: 's2',
    name: 'Kopi Kapulaga Arab (Qahwa) & Baklava',
    description: 'Seduhan kopi Arab khas tradisional bertabur kapulaga hangat, dipadukan manisnya kue lapis baklava madu.'
  },
  {
    id: 's3',
    name: 'Teh Daun Mint Madinah & Biskuit Maamoul',
    description: 'Teh hangat beraroma daun mint segar khas perkebunan Madinah, disajikan bersama kue mentega isi selai kurma.'
  },
  {
    id: 's4',
    name: 'Gorengan Sambosa Daging Renyah',
    description: '3 buah roti segitiga renyah isi daging sapi cincang berbumbu khas Timur Tengah, siap saji hangat.'
  },
  {
    id: 's5',
    name: 'Kacang Gurih Campur (Pistachio & Almond)',
    description: 'Pilihan kacang oven berkualitas tinggi yang gurih, pas untuk mendampingi waktu istirahat ibadah Anda.'
  },
  {
    id: 's6',
    name: 'Jus Jeruk Segar & Roti Panggang Madu',
    description: 'Segelas jus jeruk peras kaya vitamin C dipadukan 2 tangkep roti bakar hangat berpulas madu murni.'
  }
];

export const HOUSEKEEPING_OPTIONS = [
  { id: 'h1', label: 'Ganti Seprai & Sarung Bantal', description: 'Mengganti seluruh alas tidur dengan seprei baru yang bersih dan steril.' },
  { id: 'h2', label: 'Buang Sampah Kamar & Meja', description: 'Mengosongkan semua tempat sampah di sudut kamar dan merapikan sisa bungkus.' },
  { id: 'h3', label: 'Tambah & Ganti Handuk Mandi', description: 'Menyediakan handuk tebal putih yang wangi dan bersih dari laundry utama.' },
  { id: 'h4', label: 'Bersihkan & Sikat Kamar Mandi', description: 'Pembersihan menyeluruh area basah, kloset, wastafel, dan shower kamar mandi.' },
  { id: 'h5', label: 'Isi Ulang Amenitas (Sabun / Tisu / Air Botol)', description: 'Melengkapi kembali botol mineral, sabun mandi, sampo, sikat gigi, dan tisu wajah.' }
];
