import { useState } from 'react';
import { Navbar } from './components/Navbar';
import { PortalUser } from './components/PortalUser';
import { PortalAdmin } from './components/PortalAdmin';
import { JejakImaniText } from './components/JejakImaniBrand';
import { Heart, Building2, HelpCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function App() {
  const [activePortal, setActivePortal] = useState<'jamaah' | 'admin'>('jamaah');

  return (
    <div className="min-h-screen bg-[#FDFDFD] flex flex-col justify-between selection:bg-gold selection:text-charcoal antialiased">
      
      {/* 1. Global Navigation */}
      <Navbar activePortal={activePortal} onPortalChange={setActivePortal} />

      {/* 2. Main Content Board with micro-transitions */}
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-4">
          <AnimatePresence mode="wait">
            {activePortal === 'jamaah' ? (
              <motion.div
                key="portal-jamaah"
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                transition={{ duration: 0.2 }}
              >
                <PortalUser />
              </motion.div>
            ) : (
              <motion.div
                key="portal-admin"
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                transition={{ duration: 0.2 }}
              >
                <PortalAdmin />
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </main>

      {/* 3. Luxury Brand Footer with lowercase font constraints */}
      <footer className="bg-charcoal text-gray-400 border-t-2 border-gold pt-12 pb-8 px-4 mt-12">
        <div className="max-w-5xl mx-auto space-y-8">
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center md:text-left border-b border-gray-800 pb-8">
            {/* Guide 1 */}
            <div className="space-y-2">
              <span className="text-gold font-serif text-sm font-black tracking-wide block">Layanan Cepat</span>
              <p className="text-xs leading-relaxed text-gray-500">
                Layanan ini disediakan gratis khusus untuk jamaah <JejakImaniText className="font-bold text-gold" /> selama menginap di Arab Saudi untuk menjamin kenyamanan ibadah Anda.
              </p>
            </div>
            {/* Guide 2 */}
            <div className="space-y-2">
              <span className="text-gold font-serif text-sm font-black tracking-wide block">Ibadah Nyaman</span>
              <p className="text-xs leading-relaxed text-gray-500">
                Pembersihan kamar dan snack akan dikerjakan langsung oleh kru hotel berkolaborasi khusus dengan tim <JejakImaniText className="font-bold text-gold text-xs" />.
              </p>
            </div>
            {/* Help */}
            <div className="space-y-2">
              <span className="text-gold font-serif text-sm font-black tracking-wide block">Bantuan Darurat</span>
              <p className="text-xs leading-relaxed text-gray-500">
                Butuh bantuan medis atau kendala hotel darurat? Segera hubungi Muthawwif atau pendamping maktab terdekat Anda.
              </p>
            </div>
          </div>

          {/* Copyright signature */}
          <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-gray-500 gap-4 text-center">
            <div>
              Sistem Layanan Kamar Mandiri oleh <JejakImaniText className="text-gold font-black text-sm" />.
            </div>
            <div className="flex items-center gap-1.5 justify-center">
              <span>Khidmat Ibadah Dengan Nyaman</span>
              <Heart className="w-3.5 h-3.5 fill-gold text-gold" />
              <span>© 2026 Arab Saudi</span>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}

