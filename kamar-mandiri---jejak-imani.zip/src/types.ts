export type RequestStatus = 'Pending' | 'Diproses' | 'Selesai';

export interface SnackOrder {
  id: string;
  hotel: string;
  roomNumber: string;
  items: string[];
  quantity: number;
  status: RequestStatus;
  createdAt: string;
  updatedAt: string;
  guestId: string;
}

export interface HousekeepingRequest {
  id: string;
  hotel: string;
  roomNumber: string;
  services: string[];
  notes: string;
  status: RequestStatus;
  createdAt: string;
  updatedAt: string;
  guestId: string;
}

export interface Hotel {
  id: string;
  name: string;
  city: 'Mekkah' | 'Madinah';
}

export interface SnackItem {
  id: string;
  name: string;
  description: string;
}
