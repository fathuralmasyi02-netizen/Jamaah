import React, { useState } from 'react';

interface BrandTextProps {
  className?: string;
}

export const JejakImaniText: React.FC<BrandTextProps> = ({ className = '' }) => {
  return (
    <span className={`font-serif lowercase tracking-wider text-inherit ${className}`}>
      jejak imani
    </span>
  );
};

interface LogoProps {
  className?: string;
  size?: number;
}

export const JejakImaniLogo: React.FC<LogoProps> = ({ className = '', size = 50 }) => {
  const [hasError, setHasError] = useState(false);
  
  // High-performance direct view/download URL for Google Drive files
  const driveLogoUrl = `https://lh3.googleusercontent.com/d/1ADaHuVjVHr8tP1WuWy1q6f8bLGdFYU9a=w${size * 2}`;

  if (hasError) {
    // Beautiful premium Islamic circular geometric pattern fallback
    return (
      <div 
        className={`flex items-center justify-center rounded-full border border-gold bg-charcoal text-gold shadow-md font-serif text-center font-bold select-none ${className}`}
        style={{ width: size, height: size, fontSize: size * 0.4 }}
        title="jejak imani logo fallback"
      >
        ji
      </div>
    );
  }

  return (
    <img
      src={driveLogoUrl}
      alt="Logo jejak imani"
      className={`object-contain rounded-lg transition-transform hover:scale-105 duration-300 ${className}`}
      style={{ width: size, height: size }}
      referrerPolicy="no-referrer"
      onError={() => {
        console.warn("Direct Drive image link blocked, using stylized fallback.");
        setHasError(true);
      }}
    />
  );
};
