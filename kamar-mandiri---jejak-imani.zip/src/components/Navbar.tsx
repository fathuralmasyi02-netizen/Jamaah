import React from 'react';
import { JejakImaniLogo, JejakImaniText } from './JejakImaniBrand';
import { ShieldCheck, User, Database, AlertCircle } from 'lucide-react';
import { isFirebaseReady } from '../firebase';

interface NavbarProps {
  activePortal: 'jamaah' | 'admin';
  onPortalChange: (portal: 'jamaah' | 'admin') => void;
}

export const Navbar: React.FC<NavbarProps> = ({ activePortal, onPortalChange }) => {
  return (
    <header className="sticky top-0 z-50 w-full md:h-[80px] bg-white border-b-3 border-gold flex items-center shadow-[0_4px_15px_rgba(0,0,0,0.05)] px-4 md:px-8 py-3 sm:py-0">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="bg-charcoal p-1.5 rounded-lg shadow-inner">
            <JejakImaniLogo size={42} />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-xs uppercase font-semibold text-gold tracking-widest">Sistem Layanan Mandiri</span>
            </div>
            <h1 className="text-xl md:text-2xl font-black text-charcoal leading-tight">
              Kamar <JejakImaniText className="text-gold font-bold" />
            </h1>
          </div>
        </div>

        {/* Dynamic Connection Badge */}
        <div className="flex items-center gap-2">
          {isFirebaseReady ? (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
              <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
              Cloud Firestore Aktif
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-700 border border-amber-200" title="Sistem menggunakan penyimpanan lokal peramban sampai Firebase terms disetujui.">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
              Penyimpanan Lokal Aktif
            </span>
          )}
        </div>

        {/* Elder-friendly Access Toggle (Single click access) */}
        <div className="flex bg-gray-100 p-1.5 border border-gray-200 rounded-xl gap-1 w-full sm:w-auto">
          <button
            id="nav-btn-jamaah"
            onClick={() => onPortalChange('jamaah')}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2.5 px-6 py-3 rounded-lg text-sm font-bold transition-all duration-200 pointer-events-auto cursor-pointer ${
              activePortal === 'jamaah'
                ? 'bg-charcoal text-gold shadow-md scale-[1.02]'
                : 'text-gray-600 hover:text-charcoal hover:bg-gray-50'
            }`}
          >
            <User className={`w-5 h-5 ${activePortal === 'jamaah' ? 'text-gold' : 'text-gray-400'}`} />
            Portal Jamaah
          </button>
          
          <button
            id="nav-btn-admin"
            onClick={() => onPortalChange('admin')}
            className={`flex-1 sm:flex-initial flex items-center justify-center gap-2.5 px-6 py-3 rounded-lg text-sm font-bold transition-all duration-200 pointer-events-auto cursor-pointer ${
              activePortal === 'admin'
                ? 'bg-gold text-charcoal shadow-md scale-[1.02]'
                : 'text-gray-600 hover:text-charcoal hover:bg-gold/10'
            }`}
          >
            <ShieldCheck className={`w-5 h-5 ${activePortal === 'admin' ? 'text-charcoal' : 'text-gray-400'}`} />
            Portal Admin
          </button>
        </div>

      </div>
    </header>
  );
};
