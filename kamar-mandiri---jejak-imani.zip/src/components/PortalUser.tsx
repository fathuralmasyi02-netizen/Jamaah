import React, { useState, useEffect } from 'react';
import { HOTELS_SAUDI, SNACKS_MENU, HOUSEKEEPING_OPTIONS } from '../data';
import { dbService } from '../firebase';
import { SnackOrder, HousekeepingRequest, RequestStatus } from '../types';
import { JejakImaniText } from './JejakImaniBrand';
import { 
  Coffee, 
  Trash2, 
  Clock, 
  CheckCircle2, 
  Plus, 
  Minus, 
  MapPin, 
  Bed, 
  Send,
  Sparkles,
  ClipboardList,
  Search,
  Check,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PortalUser: React.FC = () => {
  // Navigation Local Tab inside Pilgrim Portal: 'snack' | 'cleaning' | 'status'
  const [activeTab, setActiveTab] = useState<'snack' | 'cleaning' | 'status'>('snack');
  
  // Shared Pilgrim Credentials (saves re-typing)
  const [selectedHotel, setSelectedHotel] = useState<string>('');
  const [roomNumber, setRoomNumber] = useState<string>('');
  
  // --- STATE FOR SNACK FORM ---
  const [selectedSnacks, setSelectedSnacks] = useState<string[]>([]);
  const [snackQuantity, setSnackQuantity] = useState<number>(1);
  const [snackSubmitting, setSnackSubmitting] = useState<boolean>(false);
  const [snackSuccess, setSnackSuccess] = useState<string | null>(null);

  // --- STATE FOR HOUSEKEEPING FORM ---
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  const [housekeepingNotes, setHousekeepingNotes] = useState<string>('');
  const [hkSubmitting, setHkSubmitting] = useState<boolean>(false);
  const [hkSuccess, setHkSuccess] = useState<string | null>(null);

  // --- CLIENT SESSION FOOTPRINT ---
  const [guestId, setGuestId] = useState<string>('');
  useEffect(() => {
    let id = localStorage.getItem('je_guest_id');
    if (!id) {
      id = 'gst_' + Math.random().toString(36).substring(2, 11);
      localStorage.setItem('je_guest_id', id);
    }
    setGuestId(id);
    
    // Auto populate last used hotel/room if any
    const savedHotel = localStorage.getItem('je_last_hotel');
    const savedRoom = localStorage.getItem('je_last_room');
    if (savedHotel) setSelectedHotel(savedHotel);
    if (savedRoom) setRoomNumber(savedRoom);
  }, []);

  const saveCredentialsToCache = (hotel: string, room: string) => {
    localStorage.setItem('je_last_hotel', hotel);
    localStorage.setItem('je_last_room', room);
  };

  // --- STATE FOR MONITORING STATUS ---
  const [mySnackOrders, setMySnackOrders] = useState<SnackOrder[]>([]);
  const [myHkRequests, setMyHkRequests] = useState<HousekeepingRequest[]>([]);
  
  // Search state to lookup by room/hotel manually if they are on another phone
  const [searchHotel, setSearchHotel] = useState<string>('');
  const [searchRoom, setSearchRoom] = useState<string>('');
  const [searchResults, setSearchResults] = useState<{snacks: SnackOrder[], hk: HousekeepingRequest[]} | null>(null);
  const [isSearching, setIsSearching] = useState<boolean>(false);

  // Load guest orders in real-time
  useEffect(() => {
    if (!guestId) return;

    // Listen to snacks
    const unsubSnacks = dbService.listenSnackOrders((orders) => {
      setMySnackOrders(orders);
    }, guestId);

    // Listen to housekeeping
    const unsubHk = dbService.listenHousekeeping((reqs) => {
      setMyHkRequests(reqs);
    }, guestId);

    return () => {
      unsubSnacks();
      unsubHk();
    };
  }, [guestId]);

  // Handle Search Lookup across entire Firestore for matching hotel & room
  const handleManualSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchHotel || !searchRoom) return;

    setIsSearching(true);
    
    // We register snap listeners for search fields
    const unsubS = dbService.listenSnackOrders((allOrders) => {
      const match = allOrders.filter(o => o.hotel === searchHotel && o.roomNumber.trim() === searchRoom.trim());
      const unsubH = dbService.listenHousekeeping((allHk) => {
        const matchHk = allHk.filter(r => r.hotel === searchHotel && r.roomNumber.trim() === searchRoom.trim());
        setSearchResults({
          snacks: match,
          hk: matchHk
        });
        setIsSearching(false);
      });
      return () => unsubH();
    });

    return () => unsubS();
  };

  // --- ACTION HANDLERS ---

  const handleSnackCheck = (snackName: string) => {
    if (selectedSnacks.includes(snackName)) {
      setSelectedSnacks(selectedSnacks.filter(s => s !== snackName));
    } else {
      setSelectedSnacks([...selectedSnacks, snackName]);
    }
  };

  const handleServiceCheck = (label: string) => {
    if (selectedServices.includes(label)) {
      setSelectedServices(selectedServices.filter(s => s !== label));
    } else {
      setSelectedServices([...selectedServices, label]);
    }
  };

  const submitSnackOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHotel) {
      alert("Mohon pilih nama Hotel tempat Anda menginap.");
      return;
    }
    if (!roomNumber.trim()) {
      alert("Mohon masukkan nomor kamar Anda.");
      return;
    }
    if (selectedSnacks.length === 0) {
      alert("Mohon pilih setidaknya satu sajian snack.");
      return;
    }

    setSnackSubmitting(true);
    saveCredentialsToCache(selectedHotel, roomNumber);

    try {
      const orderId = await dbService.placeSnackOrder({
        hotel: selectedHotel,
        roomNumber: roomNumber.trim(),
        items: selectedSnacks,
        quantity: snackQuantity,
        guestId: guestId
      });
      
      setSnackSuccess(orderId);
      // Reset snack choices inside form
      setSelectedSnacks([]);
      setSnackQuantity(1);
    } catch (e) {
      console.error(e);
      alert("Gagal mengirim pesanan. Silakan coba beberapa saat lagi.");
    } finally {
      setSnackSubmitting(false);
    }
  };

  const submitHousekeeping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedHotel) {
      alert("Mohon pilih nama Hotel tempat Anda menginap.");
      return;
    }
    if (!roomNumber.trim()) {
      alert("Mohon masukkan nomor kamar Anda.");
      return;
    }
    if (selectedServices.length === 0) {
      alert("Mohon tandai bagian kamar mana yang perlu dibersihkan/dilayani.");
      return;
    }

    setHkSubmitting(true);
    saveCredentialsToCache(selectedHotel, roomNumber);

    try {
      const reqId = await dbService.requestHousekeeping({
        hotel: selectedHotel,
        roomNumber: roomNumber.trim(),
        services: selectedServices,
        notes: housekeepingNotes.trim(),
        guestId: guestId
      });

      setHkSuccess(reqId);
      setSelectedServices([]);
      setHousekeepingNotes('');
    } catch (e) {
      console.error(e);
      alert("Gagal mengirim permintaan. Silakan coba lagi.");
    } finally {
      setHkSubmitting(false);
    }
  };

  // Helper classes to label status elegantly
  const randerStatusBadge = (status: RequestStatus) => {
    switch (status) {
      case 'Pending':
        return (
          <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-800 border border-amber-200 px-3 py-1.5 rounded-full font-bold text-sm">
            <Clock className="w-4 h-4 animate-spin-slow text-amber-600" />
            Menunggu Antrean
          </span>
        );
      case 'Diproses':
        return (
          <span className="inline-flex items-center gap-1 bg-charcoal text-gold border border-gold/30 px-3 py-1.5 rounded-full font-bold text-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-gold animate-ping"></span>
            Sedang Dikerjakan
          </span>
        );
      case 'Selesai':
        return (
          <span className="inline-flex items-center gap-1 bg-green-50 text-green-800 border border-green-200 px-3 py-1.5 rounded-full font-bold text-sm">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            Selesai Dilayani
          </span>
        );
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-2 sm:px-4 py-6">
      
      {/* 1. ELDER NAVIGATION BUTTONS FOR USER MAIN TABS (Maximum 2 clicks to locate everything) */}
      <div className="flex flex-wrap md:flex-nowrap bg-white border border-[#EEE] p-2 rounded-[24px] shadow-[0_10px_30px_rgba(0,0,0,0.05)] gap-2 mb-8">
        <button
          onClick={() => { setActiveTab('snack'); setSnackSuccess(null); }}
          className={`flex-1 flex flex-col sm:flex-row items-center justify-center gap-3 py-4 px-4 rounded-[16px] text-center font-bold text-base transition-luxury pointer-events-auto cursor-pointer ${
            activeTab === 'snack'
              ? 'bg-gold text-white shadow-md'
              : 'text-gray-600 hover:bg-[#F8F9FA]'
          }`}
        >
          <div className={`p-2 rounded-full ${activeTab === 'snack' ? 'bg-white/20' : 'bg-[#F8F9FA]'}`}>
            <Coffee className={`w-6 h-6 ${activeTab === 'snack' ? 'text-white' : 'text-gold'}`} />
          </div>
          <div>
            <span className="block text-sm sm:text-base leading-tight">Pesan Snack</span>
            <span className={`text-[10px] sm:text-xs font-normal block sm:inline ${activeTab === 'snack' ? 'text-white/80' : 'text-gray-400'}`}>Makanan Ringan & Air</span>
          </div>
        </button>

        <button
          onClick={() => { setActiveTab('cleaning'); setHkSuccess(null); }}
          className={`flex-1 flex flex-col sm:flex-row items-center justify-center gap-3 py-4 px-4 rounded-[16px] text-center font-bold text-base transition-luxury pointer-events-auto cursor-pointer ${
            activeTab === 'cleaning'
              ? 'bg-gold text-white shadow-md'
              : 'text-gray-600 hover:bg-[#F8F9FA]'
          }`}
        >
          <div className={`p-2 rounded-full ${activeTab === 'cleaning' ? 'bg-white/20' : 'bg-[#F8F9FA]'}`}>
            <Bed className={`w-6 h-6 ${activeTab === 'cleaning' ? 'text-white' : 'text-gold'}`} />
          </div>
          <div>
            <span className="block text-sm sm:text-base leading-tight">Pembersihan</span>
            <span className={`text-[10px] sm:text-xs font-normal block sm:inline ${activeTab === 'cleaning' ? 'text-white/80' : 'text-gray-400'}`}>Kamar Rapih & Bersih</span>
          </div>
        </button>

        <button
          onClick={() => setActiveTab('status')}
          className={`flex-1 flex flex-col sm:flex-row items-center justify-center gap-3 py-4 px-4 rounded-[16px] text-center font-bold text-base transition-luxury pointer-events-auto cursor-pointer relative ${
            activeTab === 'status'
              ? 'bg-gold text-white shadow-md'
              : 'text-gray-600 hover:bg-[#F8F9FA]'
          }`}
        >
          <div className={`p-2 rounded-full ${activeTab === 'status' ? 'bg-white/20' : 'bg-[#F8F9FA]'}`}>
            <ClipboardList className={`w-6 h-6 ${activeTab === 'status' ? 'text-white' : 'text-gold'}`} />
          </div>
          <div>
            <span className="block text-sm sm:text-base leading-tight">Pantau Status ({mySnackOrders.length + myHkRequests.length})</span>
            <span className={`text-[10px] sm:text-xs font-normal block sm:inline ${activeTab === 'status' ? 'text-white/80' : 'text-gray-400'}`}>Pantau Layanan Kamar</span>
          </div>
        </button>
      </div>

      {/* 2. DYNAMIC LAYOUT PER TAB */}
      <AnimatePresence mode="wait">
        
        {/* TAB 1: SNACK ORDERING FORM */}
        {activeTab === 'snack' && (
          <motion.div
            key="snack-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
            className="space-y-6"
          >
            {snackSuccess ? (
              <div className="bg-white border-2 border-gold rounded-2xl p-6 text-center shadow-lg space-y-4">
                <div className="w-16 h-16 bg-green-50 border border-green-200 text-green-600 flex items-center justify-center rounded-full mx-auto">
                  <Check className="w-8 h-8 font-black" />
                </div>
                <h3 className="text-2xl font-black text-charcoal">Pesanan Snack Sukses Dikirim!</h3>
                <p className="text-gray-600 max-w-md mx-auto">
                  Insya Allah petugas hotel jamaah <JejakImaniText className="font-bold text-gold" /> akan segera mengantarkan sajian Anda ke Kamar <span className="font-bold text-charcoal">{roomNumber}</span>.
                </p>
                <div className="bg-gray-50 max-w-sm mx-auto p-3 rounded-lg border border-gray-100 text-xs text-gray-500 font-mono">
                  Kode Pelacakan: #{snackSuccess}
                </div>
                <div className="flex justify-center gap-3 pt-4">
                  <button
                    onClick={() => setSnackSuccess(null)}
                    className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-charcoal font-bold rounded-xl text-sm pointer-events-auto cursor-pointer"
                  >
                    Buat Pesanan Baru
                  </button>
                  <button
                    onClick={() => setActiveTab('status')}
                    className="px-6 py-3 bg-gold hover:bg-gold-dark text-charcoal font-bold rounded-xl text-sm pointer-events-auto cursor-pointer shadow"
                  >
                    Pantau Layanan Saya
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={submitSnackOrder} className="bg-white border border-[#EEE] rounded-[24px] p-6 sm:p-8 shadow-[0_10px_30px_rgba(0,0,0,0.08)] space-y-8">
                
                {/* Header info */}
                <div className="border-b border-gray-100 pb-4">
                  <h2 className="text-xl font-bold text-charcoal tracking-tight flex items-center gap-2">
                    <Coffee className="w-5 h-5 text-gold" />
                    Penyediaan Makanan Ringan Kamar
                  </h2>
                  <p className="text-sm text-gray-500">Pilih sajian pelengkap istirahat ibadah Anda di Tanah Suci</p>
                </div>

                {/* Hotel & Room input box (Grouped, clean matching with description constraints) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label htmlFor="hotel-select" className="block text-base font-bold text-charcoal">
                      1. Nama Hotel Tempat Menginap <span className="text-amber-600">*</span>
                    </label>
                    <div className="relative">
                      <select
                        id="hotel-select"
                        value={selectedHotel}
                        onChange={(e) => {
                          setSelectedHotel(e.target.value);
                          saveCredentialsToCache(e.target.value, roomNumber);
                        }}
                        className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3.5 text-base font-medium focus:border-gold focus:bg-white focus:outline-none cursor-pointer appearance-none text-gray-800 transition-all duration-200"
                        required
                      >
                        <option value="">-- Pilih Hotel Anda --</option>
                        <optgroup label="Mekkah Mukarromah">
                          {HOTELS_SAUDI.filter(h => h.city === 'Mekkah').map(h => (
                            <option key={h.id} value={h.name}>{h.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="Madinah Al Munawwaroh">
                          {HOTELS_SAUDI.filter(h => h.city === 'Madinah').map(h => (
                            <option key={h.id} value={h.name}>{h.name}</option>
                          ))}
                        </optgroup>
                      </select>
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                        <MapPin className="w-5 h-5 text-gold" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="room-input" className="block text-base font-bold text-charcoal">
                      2. Nomor Kamar Anda <span className="text-amber-600">*</span>
                    </label>
                    <input
                      id="room-input"
                      type="text"
                      placeholder="Contoh: 1402 atau 705"
                      value={roomNumber}
                      onChange={(e) => {
                        setRoomNumber(e.target.value);
                        saveCredentialsToCache(selectedHotel, e.target.value);
                      }}
                      className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3.5 text-base font-bold focus:border-gold focus:bg-white focus:outline-none placeholder-gray-400 text-gray-800 transition-all duration-200"
                      required
                    />
                  </div>
                </div>

                {/* Snacks Selection Checklist (Large elder friendly rows) */}
                <div className="space-y-3">
                  <label className="block text-base font-bold text-charcoal">
                    3. Pilih Menu Sajian Snack (Boleh Lebih Dari Satu) <span className="text-amber-600">*</span>
                  </label>
                  
                  <div className="grid grid-cols-1 gap-3.5">
                    {SNACKS_MENU.map((item) => {
                      const isChecked = selectedSnacks.includes(item.name);
                      return (
                        <div
                          key={item.id}
                          onClick={() => handleSnackCheck(item.name)}
                          className={`flex items-start gap-4 p-4 border-2 rounded-xl cursor-pointer transition-luxury select-none ${
                            isChecked 
                              ? 'bg-gold/5 border-gold shadow-sm' 
                              : 'bg-white border-gray-100 hover:border-gray-200'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}} // Hanled by parent div onClick
                            className="w-6 h-6 mt-1 accent-gold text-gold rounded border-gray-300 focus:ring-gold pointer-events-none cursor-pointer"
                          />
                          <div className="space-y-0.5">
                            <h4 className="font-bold text-base text-charcoal">{item.name}</h4>
                            <p className="text-xs text-gray-500 font-medium leading-relaxed">{item.description}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Quantity Numeric Stepping */}
                <div className="flex flex-col sm:flex-row items-center justify-between border-t border-gray-100 pt-6 gap-4">
                  <div className="text-center sm:text-left">
                    <label className="block text-base font-bold text-charcoal">
                      4. Jumlah Kuantitas Pesanan
                    </label>
                    <span className="text-xs text-gray-500">Jumlah porsi paket makanan yang ingin diantarkan</span>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <button
                      type="button"
                      onClick={() => { if (snackQuantity > 1) setSnackQuantity(snackQuantity - 1); }}
                      className="w-12 h-12 bg-gray-100 hover:bg-gray-200 text-gray-800 font-bold rounded-full flex items-center justify-center text-xl transition-all cursor-pointer pointer-events-auto"
                    >
                      <Minus className="w-5 h-5 text-charcoal" />
                    </button>
                    
                    <span className="text-2xl font-black text-charcoal w-12 text-center select-none">
                      {snackQuantity}
                    </span>

                    <button
                      type="button"
                      onClick={() => setSnackQuantity(snackQuantity + 1)}
                      className="w-12 h-12 bg-gold/10 hover:bg-gold/20 text-gold-dark font-bold rounded-full flex items-center justify-center text-xl transition-all cursor-pointer pointer-events-auto"
                    >
                      <Plus className="w-5 h-5 text-gold-dark" />
                    </button>
                  </div>
                </div>

                {/* Big Submit Button */}
                <button
                  type="submit"
                  disabled={snackSubmitting}
                  className="w-full bg-gold hover:bg-[#A6801C] text-white py-4 rounded-[12px] text-lg font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 transition-all shadow-[0_4px_15px_rgba(212,175,55,0.25)] active:scale-[0.98] disabled:opacity-50 cursor-pointer pointer-events-auto"
                >
                  {snackSubmitting ? (
                    <div className="w-6 h-6 border-3 border-gold border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Send className="w-5 h-5 text-gold" />
                      Pesan Snack Sekarang (Hubungkan Admin)
                    </>
                  )}
                </button>

              </form>
            )}
          </motion.div>
        )}

        {/* TAB 2: HOUSEKEEPING REQUEST FORM */}
        {activeTab === 'cleaning' && (
          <motion.div
            key="cleaning-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
            className="space-y-6"
          >
            {hkSuccess ? (
              <div className="bg-white border-2 border-gold rounded-2xl p-6 text-center shadow-lg space-y-4">
                <div className="w-16 h-16 bg-green-50 border border-green-200 text-green-600 flex items-center justify-center rounded-full mx-auto">
                  <Check className="w-8 h-8 font-black" />
                </div>
                <h3 className="text-2xl font-black text-charcoal">Permintaan Pembersihan Terkirim!</h3>
                <p className="text-gray-600 max-w-md mx-auto">
                  Insya Allah kru kebersihan hotel dari <JejakImaniText className="font-bold text-gold" /> akan segera merapikan Kamar <span className="font-bold text-charcoal">{roomNumber}</span>.
                </p>
                <div className="bg-gray-50 max-w-sm mx-auto p-3 rounded-lg border border-gray-100 text-xs text-gray-500 font-mono">
                  Kode Pelacakan: #{hkSuccess}
                </div>
                <div className="flex justify-center gap-3 pt-4">
                  <button
                    onClick={() => setHkSuccess(null)}
                    className="px-6 py-3 bg-gray-100 hover:bg-gray-200 text-charcoal font-bold rounded-xl text-sm pointer-events-auto cursor-pointer"
                  >
                    Minta Kebersihan Lagi
                  </button>
                  <button
                    onClick={() => setActiveTab('status')}
                    className="px-6 py-3 bg-gold hover:bg-gold-dark text-charcoal font-bold rounded-xl text-sm pointer-events-auto cursor-pointer shadow"
                  >
                    Pantau Layanan Saya
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={submitHousekeeping} className="bg-white border border-[#EEE] rounded-[24px] p-6 sm:p-8 shadow-[0_10px_30px_rgba(0,0,0,0.08)] space-y-8">
                
                {/* Header info */}
                <div className="border-b border-gray-100 pb-4">
                  <h2 className="text-xl font-bold text-charcoal tracking-tight flex items-center gap-2">
                    <Sparkles className="w-5 h-5 text-gold" />
                    Permintaan Kebersihan Kamar (Housekeeping)
                  </h2>
                  <p className="text-sm text-gray-500">Tentukan area atau tambahan kelengkapan kamar yang Anda butuhkan</p>
                </div>

                {/* Hotel & Room input box (Grouped, synced automatically with state) */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <label htmlFor="hotel-select-hk" className="block text-base font-bold text-charcoal">
                      1. Nama Hotel Tempat Menginap <span className="text-amber-600">*</span>
                    </label>
                    <div className="relative">
                      <select
                        id="hotel-select-hk"
                        value={selectedHotel}
                        onChange={(e) => {
                          setSelectedHotel(e.target.value);
                          saveCredentialsToCache(e.target.value, roomNumber);
                        }}
                        className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3.5 text-base font-medium focus:border-gold focus:bg-white focus:outline-none cursor-pointer appearance-none text-gray-800 transition-all duration-200"
                        required
                      >
                        <option value="">-- Pilih Hotel Anda --</option>
                        <optgroup label="Mekkah Mukarromah">
                          {HOTELS_SAUDI.filter(h => h.city === 'Mekkah').map(h => (
                            <option key={h.id} value={h.name}>{h.name}</option>
                          ))}
                        </optgroup>
                        <optgroup label="Madinah Al Munawwaroh">
                          {HOTELS_SAUDI.filter(h => h.city === 'Madinah').map(h => (
                            <option key={h.id} value={h.name}>{h.name}</option>
                          ))}
                        </optgroup>
                      </select>
                      <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-gray-400">
                        <MapPin className="w-5 h-5 text-gold" />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label htmlFor="room-input-hk" className="block text-base font-bold text-charcoal">
                      2. Nomor Kamar Anda <span className="text-amber-600">*</span>
                    </label>
                    <input
                      id="room-input-hk"
                      type="text"
                      placeholder="Contoh: 1402 atau 705"
                      value={roomNumber}
                      onChange={(e) => {
                        setRoomNumber(e.target.value);
                        saveCredentialsToCache(selectedHotel, e.target.value);
                      }}
                      className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3.5 text-base font-bold focus:border-gold focus:bg-white focus:outline-none placeholder-gray-400 text-gray-800 transition-all duration-200"
                      required
                    />
                  </div>
                </div>

                {/* Housekeeping Checklist options */}
                <div className="space-y-3">
                  <label className="block text-base font-bold text-charcoal">
                    3. Pilih Layanan Kebersihan / Kelengakapan Kamar <span className="text-amber-600">*</span>
                  </label>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
                    {HOUSEKEEPING_OPTIONS.map((opt) => {
                      const isChecked = selectedServices.includes(opt.label);
                      return (
                        <div
                          key={opt.id}
                          onClick={() => handleServiceCheck(opt.label)}
                          className={`flex items-start gap-4 p-4 border-2 rounded-xl cursor-pointer transition-luxury select-none h-full ${
                            isChecked 
                              ? 'bg-gold/5 border-gold shadow-sm' 
                              : 'bg-white border-gray-100 hover:border-gray-200'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={isChecked}
                            onChange={() => {}} // Handled by parent div click
                            className="w-6 h-6 mt-1 accent-gold text-gold rounded border-gray-300 focus:ring-gold pointer-events-none cursor-pointer"
                          />
                          <div className="space-y-0.5">
                            <h4 className="font-bold text-sm text-charcoal">{opt.label}</h4>
                            <p className="text-[11px] text-gray-500 leading-normal">{opt.description}</p>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Additional Text Notes */}
                <div className="space-y-2">
                  <label htmlFor="notes-textarea" className="block text-base font-bold text-charcoal">
                    4. Catatan Tambahan Untuk Petugas (Opsional)
                  </label>
                  <textarea
                    id="notes-textarea"
                    rows={3}
                    placeholder="Contoh: Tolong sapu juga sisa debu dekat balkon, atau isi botol air mineral ekstra jika memungkinkan. Terima kasih."
                    value={housekeepingNotes}
                    onChange={(e) => setHousekeepingNotes(e.target.value)}
                    className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] p-4 text-sm focus:border-gold focus:bg-white focus:outline-none placeholder-gray-400 text-gray-800 transition-all duration-200"
                  />
                </div>

                {/* Big Submit Button */}
                <button
                  type="submit"
                  disabled={hkSubmitting}
                  className="w-full bg-gold hover:bg-[#A6801C] text-white py-4 rounded-[12px] text-lg font-bold uppercase tracking-wider flex items-center justify-center gap-2.5 transition-all shadow-[0_4px_15px_rgba(212,175,55,0.25)] active:scale-[0.98] disabled:opacity-50 cursor-pointer pointer-events-auto"
                >
                  {hkSubmitting ? (
                    <div className="w-6 h-6 border-3 border-gold border-t-transparent rounded-full animate-spin"></div>
                  ) : (
                    <>
                      <Send className="w-5 h-5 text-gold" />
                      Kirim Permintaan Kebersihan Kamar
                    </>
                  )}
                </button>

              </form>
            )}
          </motion.div>
        )}

        {/* TAB 3: ORDER AND REQUEST MONITORS (REAL TIME SYNCED) */}
        {activeTab === 'status' && (
          <motion.div
            key="status-tab"
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.25 }}
            className="space-y-8"
          >
            {/* Disclaimer info */}
            <div className="bg-white border border-[#EEE] rounded-[24px] p-6 shadow-[0_10px_30px_rgba(0,0,0,0.05)]">
              <h3 className="text-lg font-bold text-charcoal mb-1 flex items-center gap-2">
                <ClipboardList className="w-5 h-5 text-gold" />
                Daftar Permintaan Layanan Kamar
              </h3>
              <p className="text-xs text-gray-500 leading-relaxed">
                Halaman ini melacak seluruh pemesanan snack dan kebersihan yang Anda kirim dari HP/Peramban ini secara real-time. Jika status diubah oleh Admin, status di layar Anda akan seketika terupdate tanpa perlu memuat ulang peramban.
              </p>
            </div>

            {/* List Section: Current Local Session */}
            <div className="space-y-6">
              
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-200 pb-3 gap-2">
                <h4 className="text-base font-bold text-charcoal">
                  1. Layanan Aktif di Gawai Ini ({mySnackOrders.length + myHkRequests.length})
                </h4>
                <p className="text-xs text-gold-dark font-medium">Berdasarkan sidik jari penjelajahan gawai Anda</p>
              </div>

              {mySnackOrders.length === 0 && myHkRequests.length === 0 ? (
                <div className="bg-white rounded-[24px] border border-[#EEE] p-8 text-center text-gray-400 font-medium shadow-[0_10px_30px_rgba(0,0,0,0.03)]">
                  Belum ada aktivitas pesanan pada sesi browser ini.
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  
                  {/* Snack List */}
                  {mySnackOrders.map((order) => (
                    <motion.div
                      layoutId={`snack-${order.id}`}
                      key={order.id}
                      className="bg-white border border-[#EEE] rounded-[16px] p-5 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-[0_10px_25px_rgba(0,0,0,0.06)] transition-all duration-300"
                    >
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="bg-gold/10 text-gold-dark font-black px-2.5 py-1 rounded text-xs">
                            Sajian Snack
                          </span>
                          <span className="text-[10px] font-bold text-gray-400 font-mono select-all">
                            #{order.id}
                          </span>
                        </div>

                        <div>
                          <p className="font-black text-gray-700 text-sm flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-gold" />
                            {order.hotel} - Kamar {order.roomNumber}
                          </p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {new Date(order.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                          </p>
                        </div>

                        <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100/50">
                          <span className="text-xs text-gray-400 block font-bold mb-1">Rincian Paket:</span>
                          <ul className="list-disc list-inside text-xs text-gray-700 font-bold space-y-1">
                            {order.items.map((it, idx) => (
                              <li key={idx}>{it}</li>
                            ))}
                          </ul>
                          <div className="mt-2 text-xs text-charcoal font-black border-t border-gray-200/60 pt-1.5 flex justify-between">
                            <span>Kuantitas:</span>
                            <span>{order.quantity} Porsi</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between">
                        <span className="text-xs text-gray-400">Status Pengantaran:</span>
                        {randerStatusBadge(order.status)}
                      </div>
                    </motion.div>
                  ))}

                  {/* Housekeeping List */}
                  {myHkRequests.map((req) => (
                    <motion.div
                      layoutId={`hk-${req.id}`}
                      key={req.id}
                      className="bg-white border border-[#EEE] rounded-[16px] p-5 shadow-[0_4px_20px_rgba(0,0,0,0.03)] flex flex-col justify-between hover:shadow-[0_10px_25px_rgba(0,0,0,0.06)] transition-all duration-300"
                    >
                      <div className="space-y-3">
                        <div className="flex justify-between items-start">
                          <span className="bg-charcoal text-gold font-bold px-2.5 py-1 rounded text-xs border border-gold/20">
                            Pembersihan Kamar
                          </span>
                          <span className="text-[10px] font-bold text-gray-400 font-mono select-all">
                            #{req.id}
                          </span>
                        </div>

                        <div>
                          <p className="font-black text-gray-700 text-sm flex items-center gap-1.5">
                            <MapPin className="w-3.5 h-3.5 text-gold" />
                            {req.hotel} - Kamar {req.roomNumber}
                          </p>
                          <p className="text-xs text-gray-400 mt-0.5">
                            {new Date(req.createdAt).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })} WIB
                          </p>
                        </div>

                        <div className="bg-gray-50 p-2.5 rounded-lg border border-gray-100/50">
                          <span className="text-xs text-gray-400 block font-bold mb-1">Fokus Pembersihan:</span>
                          <ul className="list-disc list-inside text-xs text-gray-700 font-bold space-y-1">
                            {req.services.map((ser, idx) => (
                              <li key={idx}>{ser}</li>
                            ))}
                          </ul>
                          {req.notes && (
                            <div className="mt-2 border-t border-gray-200/60 pt-1.5">
                              <span className="text-[10px] text-gray-400 block font-bold">Catatan Jamaah:</span>
                              <p className="text-[11px] text-gray-600 line-clamp-3 italic">"{req.notes}"</p>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="mt-4 pt-3 border-t border-gray-50 flex items-center justify-between">
                        <span className="text-xs text-gray-400">Status Pekerjaan:</span>
                        {randerStatusBadge(req.status)}
                      </div>
                    </motion.div>
                  ))}

                </div>
              )}
            </div>

            {/* Manual Lookup Search Section (In case pilgrims submitted on a tablet or their phone is switched) */}
            <div className="bg-white border border-[#EEE] rounded-[24px] p-6 sm:p-8 shadow-[0_10px_30px_rgba(0,0,0,0.08)] space-y-5">
              <div className="border-b border-gray-100 pb-3">
                <h4 className="text-lg font-black text-charcoal flex items-center gap-2">
                  <Search className="w-5 h-5 text-gold" />
                  2. Cari Pesanan Secara Manual (Semua Perangkat)
                </h4>
                <p className="text-xs text-gray-400 leading-normal">
                  Jika Anda melakukan pemesanan dari perangkat tablet atau HP lain, Anda tetap bisa melacak statusnya dengan mencari Hotel dan Nomor Kamar.
                </p>
              </div>

              <form onSubmit={handleManualSearch} className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                <div className="sm:col-span-6">
                  <select
                    value={searchHotel}
                    onChange={(e) => setSearchHotel(e.target.value)}
                    className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3 text-sm focus:border-gold focus:bg-white focus:outline-none cursor-pointer appearance-none text-gray-800 transition-all duration-200"
                    required
                  >
                    <option value="">-- Pilih Hotel --</option>
                    {HOTELS_SAUDI.map(h => (
                      <option key={h.id} value={h.name}>{h.name} ({h.city})</option>
                    ))}
                  </select>
                </div>

                <div className="sm:col-span-4">
                  <input
                    type="text"
                    placeholder="Masukkan Nomor Kamar"
                    value={searchRoom}
                    onChange={(e) => setSearchRoom(e.target.value)}
                    className="w-full bg-[#FAFAFA] border-2 border-[#EEEEEE] rounded-[12px] px-4 py-3 text-sm font-bold focus:border-gold focus:bg-white focus:outline-none placeholder-gray-400 text-gray-800 transition-all duration-200"
                    required
                  />
                </div>

                <div className="sm:col-span-2">
                  <button
                    type="submit"
                    disabled={isSearching}
                    className="w-full h-full bg-gold hover:bg-[#A6801C] text-white text-xs font-bold uppercase tracking-wider rounded-[12px] py-3 flex items-center justify-center gap-2 transition-all shadow-[0_4px_10px_rgba(212,175,55,0.15)] pointer-events-auto cursor-pointer"
                  >
                    {isSearching ? 'Mencari...' : 'Cari'}
                  </button>
                </div>
              </form>

              {searchResults && (
                <div className="bg-amber-50/40 rounded-xl p-4 border border-gold/10 space-y-4">
                  <h5 className="text-sm font-black text-charcoal border-b border-gold/10 pb-2 flex justify-between">
                    <span>Hasil Pencarian Kamar {searchRoom}:</span>
                    <span className="text-xs font-normal text-gray-500">
                      Ditemukan {searchResults.snacks.length + searchResults.hk.length} data
                    </span>
                  </h5>

                  {searchResults.snacks.length === 0 && searchResults.hk.length === 0 ? (
                    <p className="text-xs text-gray-500 text-center py-3">Tidak ditemukan layanan aktif di kamar ini.</p>
                  ) : (
                    <div className="space-y-3">
                      {/* Search Snacks */}
                      {searchResults.snacks.map((order) => (
                        <div key={order.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center text-xs gap-3">
                          <div>
                            <span className="font-bold text-gray-800">Sajian Snack ({order.items.join(', ')})</span>
                            <span className="block text-[10px] text-gray-400 mt-0.5">Kode #{order.id} | Jumlah: {order.quantity} porsi</span>
                          </div>
                          <div>{randerStatusBadge(order.status)}</div>
                        </div>
                      ))}

                      {/* Search Housekeeping */}
                      {searchResults.hk.map((req) => (
                        <div key={req.id} className="bg-white p-3 rounded-lg border border-gray-100 flex justify-between items-center text-xs gap-3">
                          <div>
                            <span className="font-bold text-gray-800"> Housekeeping ({req.services.join(', ')})</span>
                            <span className="block text-[10px] text-gray-400 mt-0.5">Kode #{req.id} {req.notes && `| Catatan: ${req.notes}`}</span>
                          </div>
                          <div>{randerStatusBadge(req.status)}</div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
};
