import React, { useState, useEffect } from 'react';
import { dbService } from '../firebase';
import { SnackOrder, HousekeepingRequest, RequestStatus } from '../types';
import { JejakImaniText } from './JejakImaniBrand';
import { 
  Coffee, 
  Bed, 
  Trash2, 
  CheckCircle2, 
  Clock, 
  Lock, 
  Unlock,
  Building,
  Calendar,
  Layers,
  Sparkles,
  RotateCcw,
  Check,
  Play
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const PortalAdmin: React.FC = () => {
  // Passcode verification state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [pinCode, setPinCode] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  
  // Default PIN constant for review
  const CORRECT_PIN = '1979';

  // Submissions data
  const [snackOrders, setSnackOrders] = useState<SnackOrder[]>([]);
  const [hkRequests, setHkRequests] = useState<HousekeepingRequest[]>([]);
  
  // Filtering states
  const [adminTab, setAdminTab] = useState<'snacks' | 'hk'>('snacks');
  const [filterHotel, setFilterHotel] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Real-time listener bindings
  useEffect(() => {
    if (!isAuthenticated) return;

    // Stream all snack orders
    const unsubSnacks = dbService.listenSnackOrders((orders) => {
      setSnackOrders(orders);
    });

    // Stream all housekeeping requests
    const unsubHk = dbService.listenHousekeeping((reqs) => {
      setHkRequests(reqs);
    });

    return () => {
      unsubSnacks();
      unsubHk();
    };
  }, [isAuthenticated]);

  // Handle PIN digital keyboard click
  const handleDigitClick = (digit: string) => {
    setPinError(null);
    if (pinCode.length < 4) {
      const newPin = pinCode + digit;
      setPinCode(newPin);
      
      // Auto verify on 4th digit
      if (newPin === CORRECT_PIN) {
        setTimeout(() => {
          setIsAuthenticated(true);
        }, 300);
      } else if (newPin.length === 4) {
        setTimeout(() => {
          setPinError('PIN yang dimasukkan salah, silakan coba lagi.');
          setPinCode('');
        }, 300);
      }
    }
  };

  const clearPin = () => {
    setPinCode('');
    setPinError(null);
  };

  // Status Change operators
  const updateSnackStatus = async (id: string, status: RequestStatus) => {
    try {
      await dbService.updateSnackOrderStatus(id, status);
    } catch (e) {
      alert("Gagal merubah status: " + String(e));
    }
  };

  const updateHkStatus = async (id: string, status: RequestStatus) => {
    try {
      await dbService.updateHousekeepingStatus(id, status);
    } catch (e) {
      alert("Gagal merubah status: " + String(e));
    }
  };

  const deleteSnack = async (id: string) => {
    if (window.confirm("Hapus catatan pesanan snack ini secara permanen dari database?")) {
      await dbService.deleteSnackOrder(id);
    }
  };

  const deleteHk = async (id: string) => {
    if (window.confirm("Hapus catatan pembersihan kamar ini secara permanen dari database?")) {
      await dbService.deleteHousekeepingRequest(id);
    }
  };

  // Analytics/KPI counts
  const totalIncoming = snackOrders.length + hkRequests.length;
  const pendingCount = 
    snackOrders.filter(o => o.status === 'Pending').length + 
    hkRequests.filter(h => h.status === 'Pending').length;
  const activeWorkingCount = 
    snackOrders.filter(o => o.status === 'Diproses').length + 
    hkRequests.filter(h => h.status === 'Diproses').length;
  const completedCount = 
    snackOrders.filter(o => o.status === 'Selesai').length + 
    hkRequests.filter(h => h.status === 'Selesai').length;

  // Extract unique hotels in the active queue for filter
  const activeHotels = Array.from(new Set([
    ...snackOrders.map(o => o.hotel),
    ...hkRequests.map(h => h.hotel)
  ])).filter(Boolean);

  // Filter processes
  const filteredSnackOrders = snackOrders.filter(o => {
    const matchH = filterHotel === 'all' || o.hotel === filterHotel;
    const matchS = filterStatus === 'all' || o.status === filterStatus;
    return matchH && matchS;
  });

  const filteredHkRequests = hkRequests.filter(h => {
    const matchH = filterHotel === 'all' || h.hotel === filterHotel;
    const matchS = filterStatus === 'all' || h.status === filterStatus;
    return matchH && matchS;
  });

  // Safe time formatting
  const formatTime = (isoString: string) => {
    try {
      const dt = new Date(isoString);
      return dt.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }) + ' WIB';
    } catch (e) {
      return '--:--';
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="max-w-md mx-auto px-4 py-12">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-white border border-[#EEE] rounded-[24px] p-8 shadow-[0_10px_30px_rgba(0,0,0,0.08)] text-center space-y-6"
        >
          <div className="w-14 h-14 bg-gold/10 text-gold-dark rounded-full flex items-center justify-center mx-auto">
            <Lock className="w-7 h-7" />
          </div>
          
          <div>
            <h2 className="text-xl font-black text-charcoal">Akses Khusus Pengurus</h2>
            <p className="text-xs text-gray-500 mt-1">
              Masukkan PIN untuk masuk ke Portal Monitoring Layanan Mandiri Jamaah <JejakImaniText className="text-gold font-bold" />
            </p>
          </div>

          {/* Asterisk inputs */}
          <div className="flex justify-center gap-3">
            {[0, 1, 2, 3].map((idx) => (
              <div 
                key={idx} 
                className={`w-12 h-14 border-2 rounded-xl flex items-center justify-center text-2xl font-black transition-all ${
                  pinCode.length > idx 
                    ? 'border-gold bg-gold/10 text-charcoal' 
                    : 'border-gray-200 text-gray-300'
                }`}
              >
                {pinCode.length > idx ? '●' : ''}
              </div>
            ))}
          </div>

          {pinError && (
            <p className="text-xs text-red-600 font-bold bg-red-50 p-2.5 rounded-lg border border-red-100">{pinError}</p>
          )}

          {/* Simple digital numeric keypad, elder friendly */}
          <div className="grid grid-cols-3 gap-2 px-4">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(val => (
              <button
                key={val}
                onClick={() => handleDigitClick(val)}
                className="py-4 bg-gray-50 hover:bg-gray-100 text-charcoal font-black rounded-xl text-lg transition-transform active:scale-90 select-none cursor-pointer pointer-events-auto"
              >
                {val}
              </button>
            ))}
            <button
              onClick={clearPin}
              className="py-4 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-xl text-xs flex items-center justify-center select-none cursor-pointer pointer-events-auto"
            >
              Reset
            </button>
            <button
              onClick={() => handleDigitClick('0')}
              className="py-4 bg-gray-50 hover:bg-gray-100 text-charcoal font-black rounded-xl text-lg select-none cursor-pointer pointer-events-auto"
            >
              0
            </button>
            <div className="flex items-center justify-center text-[10px] text-gray-400 font-bold bg-gray-50 rounded-xl select-none">
              JI
            </div>
          </div>

          <div className="border-t border-gray-100 pt-4 text-center">
            <span className="text-[11px] text-gold-dark font-black tracking-wide bg-amber-50 px-2.5 py-1 rounded">
              PIN DEFAULT KEAMANAN: 1979
            </span>
          </div>

        </motion.div>
      </div>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto px-4 py-6 space-y-6">
      
      {/* AUTHENTICATED HEADER */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-charcoal text-white rounded-2xl p-6 border-b-4 border-gold gap-4 shadow-md">
        <div>
          <span className="text-xs uppercase font-extrabold text-gold tracking-widest block mb-0.5">Control Room Admin</span>
          <h2 className="text-2xl font-black text-white flex items-center gap-2">
            <Unlock className="w-5 h-5 text-gold" />
            Monitoring Room Layanan Jamaah
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Mengawasi dan melayani seluruh kebutuhan kamar jamaah <JejakImaniText className="text-gold font-bold" /> di Saudi secara seketika.
          </p>
        </div>
        <button
          onClick={() => { setIsAuthenticated(false); setPinCode(''); }}
          className="px-5 py-2.5 bg-gold hover:bg-gold-dark text-charcoal font-black text-xs rounded-xl flex items-center gap-2 transition-transform active:scale-95 pointer-events-auto cursor-pointer"
        >
          Kunci Dashboard
        </button>
      </div>

      {/* DASHBOARD STATISTICS KPI */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        
        <div className="bg-white p-6 rounded-[16px] border border-[#EEE] shadow-[0_10px_30px_rgba(0,0,0,0.05)] text-center flex flex-col justify-between min-h-[140px]">
          <h4 className="text-xs font-bold uppercase text-gray-400 tracking-wider">Total Permintaan</h4>
          <div className="text-3xl font-black text-gold py-1">{totalIncoming}</div>
          <p className="text-[11px] text-gray-400">Seluruh rilis layanan</p>
        </div>

        <div className="bg-white p-6 rounded-[16px] border border-[#EEE] shadow-[0_10px_30px_rgba(0,0,0,0.05)] text-center flex flex-col justify-between min-h-[140px]">
          <h4 className="text-xs font-bold uppercase text-amber-600 tracking-wider">Menunggu Antrean</h4>
          <div className="text-3xl font-black text-amber-500 py-1">{pendingCount}</div>
          <p className="text-[11px] text-gray-400">Belum diproses petugas</p>
        </div>

        <div className="bg-white p-6 rounded-[16px] border border-[#EEE] shadow-[0_10px_30px_rgba(0,0,0,0.05)] text-center flex flex-col justify-between min-h-[140px]">
          <h4 className="text-xs font-bold uppercase text-blue-600 tracking-wider">Sedang Dikerjakan</h4>
          <div className="text-3xl font-black text-blue-700 py-1">{activeWorkingCount}</div>
          <p className="text-[11px] text-gray-400">Dalam pengerjaan aktif</p>
        </div>

        <div className="bg-white p-6 rounded-[16px] border border-[#EEE] shadow-[0_10px_30px_rgba(0,0,0,0.05)] text-center flex flex-col justify-between min-h-[140px]">
          <h4 className="text-xs font-bold uppercase text-green-600 tracking-wider">Selesai Berhasil</h4>
          <div className="text-3xl font-black text-green-600 py-1">{completedCount}</div>
          <p className="text-[11px] text-gray-400">Sukses diantar ke kamar</p>
        </div>

      </div>

      {/* FILTER CONTROL PANEL */}
      <div className="bg-[#FAF9FA] border border-[#EEE] p-5 rounded-[24px] shadow-[0_10px_30px_rgba(0,0,0,0.03)] space-y-4">
        <h3 className="text-sm font-black text-charcoal border-b border-gray-100 pb-2">Filter Data Pengawasan</h3>
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            {/* Filter by Hotel */}
            <div className="space-y-1">
              <span className="text-[11px] text-gray-400 font-bold block">Hotel Saudi:</span>
              <select
                value={filterHotel}
                onChange={(e) => setFilterHotel(e.target.value)}
                className="bg-white border-2 border-[#EEEEEE] text-xs font-bold px-3 py-2 rounded-[12px] text-gray-800 cursor-pointer focus:border-gold focus:outline-none transition-all duration-200 pointer-events-auto"
              >
                <option value="all">Semua Hotel</option>
                {activeHotels.map((h, i) => (
                  <option key={i} value={h}>{h}</option>
                ))}
              </select>
            </div>

            {/* Filter by Status */}
            <div className="space-y-1">
              <span className="text-[11px] text-gray-400 font-bold block">Status Layanan:</span>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="bg-white border-2 border-[#EEEEEE] text-xs font-bold px-3 py-2 rounded-[12px] text-gray-800 cursor-pointer focus:border-gold focus:outline-none transition-all duration-200 pointer-events-auto"
              >
                <option value="all">Semua Status</option>
                <option value="Pending">Menunggu Antrean (Pending)</option>
                <option value="Diproses">Sedang Dikerjakan (Diproses)</option>
                <option value="Selesai">Sudah Selesai (Selesai)</option>
              </select>
            </div>
          </div>

          {/* Toggle between Snack table and HK Table */}
          <div className="flex bg-gray-100 p-1 rounded-xl self-end sm:self-auto">
            <button
              onClick={() => setAdminTab('snacks')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer pointer-events-auto ${
                adminTab === 'snacks'
                  ? 'bg-charcoal text-gold shadow'
                  : 'text-gray-500 hover:text-charcoal'
              }`}
            >
              <Coffee className="w-4 h-4 text-gold" />
              Pesanan Snack ({filteredSnackOrders.length})
            </button>
            <button
              onClick={() => setAdminTab('hk')}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-black transition-all cursor-pointer pointer-events-auto ${
                adminTab === 'hk'
                  ? 'bg-charcoal text-gold shadow'
                  : 'text-gray-500 hover:text-charcoal'
              }`}
            >
              <Bed className="w-4 h-4 text-gold" />
              Kebersihan HK ({filteredHkRequests.length})
            </button>
          </div>
        </div>
      </div>

      {/* CORE TABLES / DATA VIEWS */}
      <AnimatePresence mode="wait">
        
        {/* VIEW 1: SNACK ORDERS LIST */}
        {adminTab === 'snacks' && (
          <motion.div
            key="snacks-table"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-white border border-[#EEE] rounded-[24px] overflow-hidden shadow-[0_10px_30px_rgba(0,0,0,0.05)]"
          >
            <div className="bg-charcoal px-5 py-4 border-b border-gold/15 flex justify-between items-center text-white">
              <h3 className="font-black text-sm tracking-wide flex items-center gap-2">
                <Coffee className="w-4.5 h-4.5 text-gold" />
                Daftar Pesanan Snack Masuk (Real-time)
              </h3>
              <span className="text-xs bg-gold/10 text-gold font-bold px-3 py-1 rounded-full">
                {filteredSnackOrders.length} Pesanan Ditemukan
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-gray-50 text-xs font-extrabold text-gray-500 border-b border-gray-100 uppercase tracking-wider select-none">
                    <th className="px-5 py-4">Waktu & Kode</th>
                    <th className="px-5 py-4">Kamar / Hotel</th>
                    <th className="px-5 py-4">Sajian Snack</th>
                    <th className="px-5 py-4">Kuantitas</th>
                    <th className="px-5 py-4">Status Layanan</th>
                    <th className="px-5 py-4 text-center">Tindakan Petugas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-sm">
                  {filteredSnackOrders.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-gray-400 font-medium">
                        Tidak ada pesanan snack yang terdaftar dalam rentang filter ini.
                      </td>
                    </tr>
                  ) : (
                    filteredSnackOrders.map((order) => (
                      <tr key={order.id} className="hover:bg-gray-50/40 transition-colors">
                        {/* Time & Track */}
                        <td className="px-5 py-4.5">
                          <div className="font-black text-charcoal">{formatTime(order.createdAt)}</div>
                          <span className="text-[10px] bg-gray-100 text-gray-400 font-mono font-bold px-1.5 py-0.5 rounded block w-fit mt-1">
                            #{order.id}
                          </span>
                        </td>
                        {/* Room and Hotel */}
                        <td className="px-5 py-4.5">
                          <div className="font-extrabold text-gray-800 text-sm">Kamar {order.roomNumber}</div>
                          <div className="text-xs text-gray-400 font-semibold flex items-center gap-1 mt-0.5">
                            <Building className="w-3.5 h-3.5 text-gold" />
                            {order.hotel}
                          </div>
                        </td>
                        {/* Snack Items */}
                        <td className="px-5 py-4.5">
                          <ul className="list-disc list-inside text-xs font-bold text-gray-700 space-y-1">
                            {order.items.map((it, i) => (
                              <li key={i}>{it}</li>
                            ))}
                          </ul>
                        </td>
                        {/* Quantity */}
                        <td className="px-5 py-4.5 font-bold text-charcoal text-center sm:text-left">
                          <span className="bg-amber-50 text-gold-dark border border-gold/15 px-2.5 py-1 rounded text-xs">
                            {order.quantity} Porsi
                          </span>
                        </td>
                        {/* Status Label */}
                        <td className="px-5 py-4.5">
                          {order.status === 'Pending' && (
                            <span className="text-xs font-bold bg-amber-50 text-amber-700 px-3 py-1.5 rounded-full border border-amber-200 inline-flex items-center gap-1">
                              Waiting
                            </span>
                          )}
                          {order.status === 'Diproses' && (
                            <span className="text-xs font-bold bg-charcoal text-gold px-3 py-1.5 rounded-full border border-gold/30 inline-flex items-center gap-1">
                              Processing
                            </span>
                          )}
                          {order.status === 'Selesai' && (
                            <span className="text-xs font-bold bg-green-50 text-green-700 px-3 py-1.5 rounded-full border border-green-200 inline-flex items-center gap-1">
                              Completed
                            </span>
                          )}
                        </td>
                        {/* Action buttons */}
                        <td className="px-5 py-4.5">
                          <div className="flex justify-center items-center gap-2">
                            {order.status !== 'Diproses' && order.status !== 'Selesai' && (
                              <button
                                onClick={() => updateSnackStatus(order.id, 'Diproses')}
                                className="px-3 py-1.5 bg-charcoal hover:bg-black text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer pointer-events-auto"
                                title="Mulai proses pengantaran"
                              >
                                <Play className="w-3 h-3 text-gold" />
                                Proses
                              </button>
                            )}

                            {order.status !== 'Selesai' && (
                              <button
                                onClick={() => updateSnackStatus(order.id, 'Selesai')}
                                className="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer pointer-events-auto"
                                title="Selesaikan layanan"
                              >
                                <Check className="w-3 h-3 text-white" />
                                Selesai
                              </button>
                            )}

                            <button
                              onClick={() => deleteSnack(order.id)}
                              className="p-1.5 hover:bg-red-50 text-red-600 hover:text-red-700 rounded-lg transition-colors cursor-pointer pointer-events-auto"
                              title="Hapus rekaman"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* VIEW 2: HOUSEKEEPING REQUESTS LIST */}
        {adminTab === 'hk' && (
          <motion.div
            key="hk-table"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-white border border-[#EEE] rounded-[24px] overflow-hidden shadow-[0_10px_30px_rgba(0,0,0,0.05)]"
          >
            <div className="bg-charcoal px-5 py-4 border-b border-gold/15 flex justify-between items-center text-white">
              <h3 className="font-black text-sm tracking-wide flex items-center gap-2">
                <Bed className="w-4.5 h-4.5 text-gold" />
                Daftar Permintaan Kebersihan Kamar (Real-time)
              </h3>
              <span className="text-xs bg-gold/10 text-gold font-bold px-3 py-1 rounded-full">
                {filteredHkRequests.length} Permintaan Ditemukan
              </span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse min-w-[700px]">
                <thead>
                  <tr className="bg-gray-50 text-xs font-extrabold text-gray-500 border-b border-gray-100 uppercase tracking-wider select-none">
                    <th className="px-5 py-4">Waktu & Kode</th>
                    <th className="px-5 py-4">Kamar / Hotel</th>
                    <th className="px-5 py-4">Layanan Kebersihan</th>
                    <th className="px-5 py-4">Catatan Tambahan</th>
                    <th className="px-5 py-4">Status Layanan</th>
                    <th className="px-5 py-4 text-center">Tindakan Petugas</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 text-sm">
                  {filteredHkRequests.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-gray-400 font-medium">
                        Tidak ada permintaan kebersihan yang terdaftar dalam rentang filter ini.
                      </td>
                    </tr>
                  ) : (
                    filteredHkRequests.map((req) => (
                      <tr key={req.id} className="hover:bg-gray-50/40 transition-colors">
                        {/* Time & Track */}
                        <td className="px-5 py-4.5">
                          <div className="font-black text-charcoal">{formatTime(req.createdAt)}</div>
                          <span className="text-[10px] bg-gray-100 text-gray-400 font-mono font-bold px-1.5 py-0.5 rounded block w-fit mt-1">
                            #{req.id}
                          </span>
                        </td>
                        {/* Room and Hotel */}
                        <td className="px-5 py-4.5">
                          <div className="font-extrabold text-gray-800 text-sm">Kamar {req.roomNumber}</div>
                          <div className="text-xs text-gray-400 font-semibold flex items-center gap-1 mt-0.5">
                            <Building className="w-3.5 h-3.5 text-gold" />
                            {req.hotel}
                          </div>
                        </td>
                        {/* Cleaning Options */}
                        <td className="px-5 py-4.5">
                          <ul className="list-disc list-inside text-xs font-bold text-gray-700 space-y-1">
                            {req.services.map((ser, i) => (
                              <li key={i}>{ser}</li>
                            ))}
                          </ul>
                        </td>
                        {/* Staff notes */}
                        <td className="px-5 py-4.5 max-w-xs">
                          {req.notes ? (
                            <p className="text-xs font-medium text-gray-600 italic bg-gray-50 border border-gray-100 p-2 rounded-lg line-clamp-3 leading-relaxed">
                              "{req.notes}"
                            </p>
                          ) : (
                            <span className="text-xs text-gray-300 font-medium italic">Tidak ada catatan untuk petugas</span>
                          )}
                        </td>
                        {/* Status Label */}
                        <td className="px-5 py-4.5">
                          {req.status === 'Pending' && (
                            <span className="text-xs font-bold bg-amber-50 text-amber-700 px-3 py-1.5 rounded-full border border-amber-200 inline-flex items-center gap-1">
                              Waiting
                            </span>
                          )}
                          {req.status === 'Diproses' && (
                            <span className="text-xs font-bold bg-charcoal text-gold px-3 py-1.5 rounded-full border border-gold/30 inline-flex items-center gap-1">
                              Processing
                            </span>
                          )}
                          {req.status === 'Selesai' && (
                            <span className="text-xs font-bold bg-green-50 text-green-700 px-3 py-1.5 rounded-full border border-green-200 inline-flex items-center gap-1">
                              Completed
                            </span>
                          )}
                        </td>
                        {/* Action buttons */}
                        <td className="px-5 py-4.5">
                          <div className="flex justify-center items-center gap-2">
                            {req.status !== 'Diproses' && req.status !== 'Selesai' && (
                              <button
                                onClick={() => updateHkStatus(req.id, 'Diproses')}
                                className="px-3 py-1.5 bg-charcoal hover:bg-black text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer pointer-events-auto"
                                title="Mulai proses pembersihan"
                              >
                                <Play className="w-3 h-3 text-gold" />
                                Proses
                              </button>
                            )}

                            {req.status !== 'Selesai' && (
                              <button
                                onClick={() => updateHkStatus(req.id, 'Selesai')}
                                className="px-3 py-1.5 bg-green-600 hover:bg-green-700 text-white text-xs font-bold rounded-lg flex items-center gap-1 cursor-pointer pointer-events-auto"
                                title="Selesaikan kebersihan kamar"
                              >
                                <Check className="w-3 h-3 text-white" />
                                Selesai
                              </button>
                            )}

                            <button
                              onClick={() => deleteHk(req.id)}
                              className="p-1.5 hover:bg-red-50 text-red-600 hover:text-red-700 rounded-lg transition-colors cursor-pointer pointer-events-auto"
                              title="Hapus rekaman"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

      </AnimatePresence>

      {/* QUICK LAUNCH DUMMY CREATOR Helper (Just for easy immediate testing) */}
      <div className="bg-white border border-gray-100 p-4 rounded-xl shadow-inner flex flex-col sm:flex-row items-center justify-between text-xs gap-4">
        <div className="text-gray-500 font-medium text-center sm:text-left">
          💡 <span className="font-extrabold text-charcoal">Mode Simulasi Instan:</span> Gunakan tombol di samping kanan untuk menyuntikkan data sampel secara instan guna menguji jalannya antrean real-time portal Anda!
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={async () => {
              await dbService.placeSnackOrder({
                hotel: 'Pullman Zamzam Makkah',
                roomNumber: '1204',
                items: ['Paket Kurma Ajwa & Air Zamzam Utama', 'Kopi Kapulaga Arab (Qahwa) & Baklava'],
                quantity: 2,
                guestId: 'simulated_guest'
              });
            }}
            className="px-3 py-1.5 bg-gold/10 hover:bg-gold/20 text-gold-dark font-bold rounded-lg pointer-events-auto cursor-pointer"
          >
            + Simulasi Snack
          </button>
          
          <button
            onClick={async () => {
              await dbService.requestHousekeeping({
                hotel: 'Dar Al Iman InterContinental Madinah',
                roomNumber: '805',
                services: ['Ganti Seprai & Sarung Bantal', 'Isi Ulang Amenitas (Sabun / Tisu / Air Botol)'],
                notes: 'Tolong ditaruh dekat wastafel, terima kasih banyak.',
                guestId: 'simulated_guest'
              });
            }}
            className="px-3 py-1.5 bg-charcoal/5 hover:bg-charcoal/10 text-charcoal font-bold rounded-lg pointer-events-auto cursor-pointer"
          >
            + Simulasi Housekeeping
          </button>
        </div>
      </div>

    </div>
  );
};
