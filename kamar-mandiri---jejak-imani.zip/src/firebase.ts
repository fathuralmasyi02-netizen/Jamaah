import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { 
  getFirestore, 
  collection, 
  addDoc, 
  onSnapshot, 
  updateDoc, 
  doc, 
  deleteDoc, 
  query, 
  where, 
  orderBy,
  serverTimestamp,
  doc as firestoreDoc,
  getDocFromServer
} from 'firebase/firestore';
import { SnackOrder, HousekeepingRequest, RequestStatus } from './types';
import firebaseConfig from '../firebase-applet-config.json';

// Detect if Firebase has been configured with real keys
export const isFirebaseReady = 
  firebaseConfig.apiKey && 
  firebaseConfig.apiKey !== 'dummy-api-key-to-allow-compile' && 
  firebaseConfig.projectId !== 'dummy-project-id';

let db: any = null;
let auth: any = null;

if (isFirebaseReady) {
  try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app, firebaseConfig.firestoreDatabaseId || '(default)');
    auth = getAuth(app);
    
    // Validate connection is online
    const testConnection = async () => {
      try {
        await getDocFromServer(firestoreDoc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.warn("Firestore client is offline, using offline capabilities.");
        }
      }
    };
    testConnection();
  } catch (error) {
    console.error("Failed to initialize Firebase SDK:", error);
  }
}

// Error logger according to skill rules
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth?.currentUser?.uid || null,
      email: auth?.currentUser?.email || null,
    },
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- LOCAL STORAGE PERSISTENCE FALLBACKS ---
// Used when Firebase is not configured or fails to load

const getLocalStorageSnacks = (): SnackOrder[] => {
  const data = localStorage.getItem('je_snack_orders');
  return data ? JSON.parse(data) : [];
};

const setLocalStorageSnacks = (orders: SnackOrder[]) => {
  localStorage.setItem('je_snack_orders', JSON.stringify(orders));
  // Dispatch a custom event to notify other instances of the same page tab
  window.dispatchEvent(new Event('je_db_update'));
};

const getLocalStorageHK = (): HousekeepingRequest[] => {
  const data = localStorage.getItem('je_hk_requests');
  return data ? JSON.parse(data) : [];
};

const setLocalStorageHK = (reqs: HousekeepingRequest[]) => {
  localStorage.setItem('je_hk_requests', JSON.stringify(reqs));
  window.dispatchEvent(new Event('je_db_update'));
};

// --- SYSTEM API ---

export const dbService = {
  // Save new snack order
  async placeSnackOrder(order: Omit<SnackOrder, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<string> {
    const id = Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const newOrder: SnackOrder = {
      ...order,
      id,
      status: 'Pending',
      createdAt: now,
      updatedAt: now
    };

    if (isFirebaseReady && db) {
      try {
        const docRef = await addDoc(collection(db, 'snack_orders'), {
          ...newOrder,
          createdAt: now, // store as string/ISO for consistency with schemas Or can use serverTimestamp()
          updatedAt: now
        });
        return docRef.id;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'snack_orders');
      }
    }

    // Local Storage Mock
    const current = getLocalStorageSnacks();
    current.unshift(newOrder); // Add to beginning of array
    setLocalStorageSnacks(current);
    return id;
  },

  // Save new housekeeping request
  async requestHousekeeping(request: Omit<HousekeepingRequest, 'id' | 'createdAt' | 'updatedAt' | 'status'>): Promise<string> {
    const id = Math.random().toString(36).substring(2, 11);
    const now = new Date().toISOString();
    const newRequest: HousekeepingRequest = {
      ...request,
      id,
      status: 'Pending',
      createdAt: now,
      updatedAt: now
    };

    if (isFirebaseReady && db) {
      try {
        const docRef = await addDoc(collection(db, 'housekeeping_requests'), {
          ...newRequest,
          createdAt: now,
          updatedAt: now
        });
        return docRef.id;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'housekeeping_requests');
      }
    }

    // Local Storage Mock
    const current = getLocalStorageHK();
    current.unshift(newRequest);
    setLocalStorageHK(current);
    return id;
  },

  // Listen to snack orders
  listenSnackOrders(onUpdate: (orders: SnackOrder[]) => void, guestId?: string) {
    if (isFirebaseReady && db) {
      const collRef = collection(db, 'snack_orders');
      // Create query
      let q = query(collRef, orderBy('createdAt', 'desc'));
      if (guestId) {
        q = query(collRef, where('guestId', '==', guestId), orderBy('createdAt', 'desc'));
      }

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const orders: SnackOrder[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          orders.push({
            id: doc.id,
            hotel: data.hotel || '',
            roomNumber: data.roomNumber || '',
            items: data.items || [],
            quantity: data.quantity || 1,
            status: data.status || 'Pending',
            createdAt: data.createdAt || new Date().toISOString(),
            updatedAt: data.updatedAt || new Date().toISOString(),
            guestId: data.guestId || ''
          });
        });
        onUpdate(orders);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'snack_orders');
      });
      return unsubscribe;
    }

    // Local Storage Fallback with reactive event listener
    const handleUpdate = () => {
      let current = getLocalStorageSnacks();
      if (guestId) {
        current = current.filter(o => o.guestId === guestId);
      }
      onUpdate(current);
    };

    handleUpdate(); // initial load
    window.addEventListener('storage', handleUpdate);
    window.addEventListener('je_db_update', handleUpdate);

    return () => {
      window.removeEventListener('storage', handleUpdate);
      window.removeEventListener('je_db_update', handleUpdate);
    };
  },

  // Listen to housekeeping requests
  listenHousekeeping(onUpdate: (reqs: HousekeepingRequest[]) => void, guestId?: string) {
    if (isFirebaseReady && db) {
      const collRef = collection(db, 'housekeeping_requests');
      let q = query(collRef, orderBy('createdAt', 'desc'));
      if (guestId) {
        q = query(collRef, where('guestId', '==', guestId), orderBy('createdAt', 'desc'));
      }

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const reqs: HousekeepingRequest[] = [];
        snapshot.forEach((doc) => {
          const data = doc.data();
          reqs.push({
            id: doc.id,
            hotel: data.hotel || '',
            roomNumber: data.roomNumber || '',
            services: data.services || [],
            notes: data.notes || '',
            status: data.status || 'Pending',
            createdAt: data.createdAt || new Date().toISOString(),
            updatedAt: data.updatedAt || new Date().toISOString(),
            guestId: data.guestId || ''
          });
        });
        onUpdate(reqs);
      }, (error) => {
        handleFirestoreError(error, OperationType.LIST, 'housekeeping_requests');
      });
      return unsubscribe;
    }

    // Local Storage Fallback
    const handleUpdate = () => {
      let current = getLocalStorageHK();
      if (guestId) {
        current = current.filter(r => r.guestId === guestId);
      }
      onUpdate(current);
    };

    handleUpdate(); // initial load
    window.addEventListener('storage', handleUpdate);
    window.addEventListener('je_db_update', handleUpdate);

    return () => {
      window.removeEventListener('storage', handleUpdate);
      window.removeEventListener('je_db_update', handleUpdate);
    };
  },

  // Update Snack Order Status
  async updateSnackOrderStatus(id: string, status: RequestStatus): Promise<void> {
    const now = new Date().toISOString();
    if (isFirebaseReady && db) {
      try {
        const docRef = doc(db, 'snack_orders', id);
        await updateDoc(docRef, { status, updatedAt: now });
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `snack_orders/${id}`);
      }
    }

    // Local manual update
    const current = getLocalStorageSnacks();
    const updated = current.map(o => o.id === id ? { ...o, status, updatedAt: now } : o);
    setLocalStorageSnacks(updated);
  },

  // Update Housekeeping Status
  async updateHousekeepingStatus(id: string, status: RequestStatus): Promise<void> {
    const now = new Date().toISOString();
    if (isFirebaseReady && db) {
      try {
        const docRef = doc(db, 'housekeeping_requests', id);
        await updateDoc(docRef, { status, updatedAt: now });
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `housekeeping_requests/${id}`);
      }
    }

    // Local manual update
    const current = getLocalStorageHK();
    const updated = current.map(r => r.id === id ? { ...r, status, updatedAt: now } : r);
    setLocalStorageHK(updated);
  },

  // Delete Snack Order
  async deleteSnackOrder(id: string): Promise<void> {
    if (isFirebaseReady && db) {
      try {
        const docRef = doc(db, 'snack_orders', id);
        await deleteDoc(docRef);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `snack_orders/${id}`);
      }
    }

    // Local manual delete
    const current = getLocalStorageSnacks();
    const updated = current.filter(o => o.id !== id);
    setLocalStorageSnacks(updated);
  },

  // Delete Housekeeping Request
  async deleteHousekeepingRequest(id: string): Promise<void> {
    if (isFirebaseReady && db) {
      try {
        const docRef = doc(db, 'housekeeping_requests', id);
        await deleteDoc(docRef);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.DELETE, `housekeeping_requests/${id}`);
      }
    }

    // Local manual delete
    const current = getLocalStorageHK();
    const updated = current.filter(r => r.id !== id);
    setLocalStorageHK(updated);
  }
};
